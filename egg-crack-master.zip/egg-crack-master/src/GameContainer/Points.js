import React from 'react';
function Points(props) {
    return(
        <p> Points: {props.points} </p>
    );
}

export default Points;