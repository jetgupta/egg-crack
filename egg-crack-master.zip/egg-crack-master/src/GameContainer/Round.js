import React from 'react';

function Round(props) {
    return(
        <p> Round: {props.round} </p>
    );
}

export default Round;