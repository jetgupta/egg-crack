import React from 'react';
import './App.css';

function Title(props) {
    return(
        <h1 className='Title'> EggCrack</h1>
    );
}

export default Title;