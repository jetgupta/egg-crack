# egg-crack

A little game to better understand the Monty Hall problem.

You can play me at [my website](https://hlehv.github.io/egg-crack)
